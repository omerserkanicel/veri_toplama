from nltk.stem import WordNetLemmatizer
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.probability import FreqDist


nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')


text ='''
[<div class="content">
<div class="post-views content-post post-3433 entry-meta">
<span class="post-views-icon dashicons dashicons-visibility"></span> <span class="post-views-label">BU YAZIYI OKUYAN KİŞİ SAYISI :</span> <span class="post-views-count">4.693</span>
</div><p><span style="color: #000000;"><strong>Köyün birinde yaşlı bir adam varmış. Çok fakirmiş ama Kral bile onu kıskanırmış. Öyle dillere destan bir beyaz atı varmış ki, Kral bu at için ihtiyara büyük bir servet teklif etmiş ama adam satmaya yanaşmamış.</strong></span></p>
<p><span style="color: #000000;">“Bu at, sadece <strong>bir at değil</strong> benim için; <strong>bir dost</strong>. insan <strong>dostunu satar mı</strong>?” demiş. Bir sabah kalkmışlar ki, at yok. Köylü ihtiyarın başına toplanmış:</span></p>
<p><span style="color: #000000;">“Seni ihtiyar bunak, bu atı sana bırakmayacakları, çalacakları belliydi. <strong>Krala satsaydın</strong>, ömrünün sonuna kadar beyler gibi yaşardın. <strong>Şimdi ne paran var, ne de atın</strong>” demişler.</span></p>
<p><span style="color: #000000;">İhtiyar: “Karar vermek için acele etmeyin” demiş. “<strong>Sadece at kayıp</strong>” deyin, “Çünkü gerçek bu. Ondan ötesi sizin yorumunuz ve verdiğiniz karar. Atımın kaybolması, bir talihsizlik mi, yoksa bir şans mı? Bunu henüz bilmiyoruz. Çünkü bu olay henüz bir başlangıç.<strong> Arkasının nasıl geleceğini kimse bilemez.”</strong></span></p>
<p><span style="color: #000000;">Köylüler ihtiyara kahkahalarla gülmüşler. <strong>Aradan 15 gün geçmiş ve at bir gece ansızın dönmüş</strong>. Meğer çalınmamış, dağlara gitmiş. Dönerken de, <strong>vadideki 12 vahşi atı peşine takıp getirmiş</strong>. Bunu gören köylüler toplanıp ithiyara gidip özür dilemişler.</span><br/>
<span style="color: #000000;">“Babalık” demişler, “Sen haklı çıktın. <strong>Atının kaybolması bir talihsizlik değil</strong> adeta bir devlet kuşu oldu senin için, şimdi bir at sürün var.”</span></p>
<p><span style="color: #000000;">“<strong>Karar vermek için gene acele ediyorsunuz</strong>” demiş ihtiyar. “Sadece atın geri döndüğünü söyleyin. Bilinen gerçek sadece bu. Ondan ötesinin ne getireceğini henüz bilmiyoruz.”</span></p>
<p><span style="color: #000000;">Köylüler bu defa açıkça ihtiyarla dalga geçmemişler ancak içlerinden “<strong>Bu ihtiyar sahiden saf</strong>” diye geçirmişler. Bir hafta geçmeden, vahşi atları terbiye etmeye çalışan ihtiyarın tek oğlu attan düşmüş ve ayağını kırmış. Evin geçimini sağlayan oğul şimdi uzun zaman yatakta kalacakmış. Köylüler gene gelmişler ihtiyara.</span></p>
<p><span style="color: #000000;">“<strong>Bir kez daha haklı çıktın</strong>” demişler. “Bu atlar yüzünden tek oğlun, bacağını uzun süre kullanamayacak. Oysa sana bakacak başkası da yok. Şimdi eskisinden daha fakir, daha zavallı olacaksın” demişler. İhtiyar “Siz erken karar verme hastalığına tutulmuşsunuz” diye cevap vermiş.</span></p>
<p><span style="color: #000000;">“<strong>O kadar acele etmeyin.</strong> Oğlum bacağını kırdı. Gerçek bu. Ötesi sizin verdiğiniz karar. Ama acaba ne kadar doğru. Hayat böyle küçük parçalar halinde gelir ve ondan sonra neler olacağını asla bilemezsiniz”</span></p>
<p><span style="color: #000000;">Birkaç hafta sonra düşmanlar hanedanlığa çok büyük bir ordu ile saldırmış. Kral son bir ümitle eli silah tutan bütün gençleri askere gönderme emrini vermiş. Köye gelen görevliler, ihtiyarın kırık bacaklı oğlu dışında bütün gençleri askere almışlar. <strong>Köyü matem sarmış. Çünkü savaşın kazanılmasına imkân yokmuş,</strong> giden gençlerin ya öleceğini ya da esir düşeceğini herkes biliyormuş.</span></p>
<p><span style="color: #000000;">Köylüler, gene ihtiyara gelmişler. “<strong>Gene haklı olduğun kanıtlandı</strong>” demişler. “Oğlunun bacağı kırık ama hiç değilse yanında. Oysa bizimkiler, belki asla köye dönemeyecekler. Oğlunun bacağının kırılması,</span><br/>
<span style="color: #000000;">talihsizlik değil, şansmış meğer…”</span></p>
<p><span style="color: #000000;">“<strong>Siz erken karar vermeye devam edin</strong>” demiş, ihtiyar. “Oysa ne olacağını kimseler bilemez. Bilinen bir tek gerçek var. Benim oğlum yanımda, sizinkiler askerde. Ama bunların hangisinin talih, hangisinin şanssızlık olduğunu sadece Allah biliyor.”</span></p>
<p><span style="color: #ff0000;"><em><strong>Lao Tzu, öyküsünü şu nasihatla tamamlamış:</strong></em></span><br/>
<span style="color: #000000;">“Acele karar vermeyin. Hayatın küçük bir dilimine bakıp tamamı hakkında karar vermekten kaçının. Karar; aklın durması halidir. Karar verdiniz mi, akıl düşünmeyi, dolayısı ile gelişmeyi durdurur. Buna rağmen akıl, insanı daima karara zorlar. Oysa gezi asla sona ermez. Bir yol biterken yenisi başlar. Bir kapı kapanırken, başkası açılır. Bir hedefe ulaşırsınız ve daha yüksek bir hedefin hemen oracıkta olduğunu görürsünüz.”</span></p>
</div>]
[<div class="content">
<div class="post-views content-post post-440 entry-meta">
<span class="post-views-icon dashicons dashicons-visibility"></span> <span class="post-views-label">BU YAZIYI OKUYAN KİŞİ SAYISI :</span> <span class="post-views-count">2.124</span>
</div><p><strong>Vaktiyle ergin bir meslek erbabı, yıllarca yanında yetiştirdiği çırağını imtihan etmek ister. Onun eline iri bir pırlanta verip:</strong></p>
<p>”Oğlum” der ”Bunu al, önüne gelen esnafa göster, kaç para verdiklerini sor, en sonra da kuyumcuya göster. Hiç kimseye satmadan sadece fiyatlarını ve ne dediklerini öğren, gel bana bildir.”</p>
<p>Çırak, elinde pırlanta bir bakkal dükkanına girer ve ”<strong>Şunu alır mısınız?</strong>” diye sorar.</p>
<p>Bakkal parlak bir boncuğa benzettiği mücevheri alır; elinde evirir çevirir; sonra: ”<strong>Buna bir tek lira veririm. Bizim çocuk oynasın</strong>” der.</p>
<p>Çırak teşekkür edip çıkar. Bir manifaturacıya gider. O da parlak bir taşa benzettiği mücevhere ancak bir beş lira vermeye razı olur.</p>
<p>Üçüncü olarak semerciye gider: ”Buna ne verirsiniz?” diye sorar.</p>
<p>Semerci şöyle bir bakar, ”Bu…” der ”<strong>benim semerlere iyi süs olur. Bundan kaş dediğimiz süslerden yaparım. Buna bir on lira veririm</strong>.”</p>
<p>Çırak en son olarak kuyumcuya gider. Kuyumcu mücevheri görünce yerinden fırlar. ”Bu kadar büyük pırlantayı nereden buldun?” diye hayretle bağırır ve hemen ilâve eder; ”Buna kaç lira istiyorsun?”</p>
<p>Çırak sorar: ”<strong>Siz ne veriyorsunuz? ” ”Ne istiyorsan veririm.</strong>”</p>
<p>Çırak, ”Hayır veremem.” diye taşı almak için uzanınca kuyumcu yalvarmaya başlar:”<strong>Ne olur bunu bana sat. Dükkânımı, evimi, hatta arsalarımı vereyim.”</strong></p>
<p>Çırak ”emanet olduğunu, satmaya yetkili olmadığını, ancak fiyat öğrenmesini istediklerini” anlatıncaya kadar bir hayli dil döker.Meslek erbabının yanına dönen çırak büyük bir şaşkınlık içinde macerasını anlatır.”Bundan ne anladın?” diye sorar.</p>
<p>Çırağının verdiği cevap çok doğrudur: ”<strong>Bir şey ancak değerini bilenin yanında kıymetlidir.”</strong></p>
</div>]
[<div class="content">
<div class="post-views content-post post-2654 entry-meta">
<span class="post-views-icon dashicons dashicons-visibility"></span> <span class="post-views-label">BU YAZIYI OKUYAN KİŞİ SAYISI :</span> <span class="post-views-count">6.688</span>
</div><p>Bir gün, bir kozada küçük bir delik açıldı ve bir adam bedenini bu küçücük delikten çıkarmaya çalışan kelebeği saatlerce seyretti.</p>
<p>Sonra, kelebek sanki daha fazla ilerlemek istemiyormuş gibi durdu. Sanki,ilerleyebileceği kadar ilerlemişti ve artık daha fazla ilerleyemiyordu. Ve adam, kelebeğe yardim etmeye karar verdi. Eline bir makas aldı ve kozayı keserek deliği büyüttü.</p>
<p>Kelebek kolayca dışarı çıktı.</p>
<p>Fakat bedeni kocaman ve kanatları kuru ve buruşuktu.<br/>
Adam, kelebeği izlemeye devam etti, çünkü zamanla kanatlarının büyüyüp bedenini taşıyabilecek kadar genişleyebileceğini umut ediyordu.</p>
<p>Fakat bu olmadı!</p>
<p>Gerçekte, kelebek ömrünün geri kalanını o kocaman bedeni ve kuru, buruşuk kanatları ile etrafta sürünerek geçirdi. Uçmayı hiç başaramadı.</p>
<p>Adamın bu aceleci iyiliği içinde anlayamadığı, bu kısıtlayıcı kozanın ve kelebeğin o küçücük delikten dışarı çıkmak için verdiği mücadelenin, kelebek için gerekli olduğuydu, çünkü bu, Allah´ın, yasam sıvısının kelebeğin bedeninden kanatlarına doğru akmasını sağlamak için bulduğu yoldu, böylece kelebek kozadan kurtulduğu anda uçmaya hazır olabilecekti.</p>
<p>Bazen mücadeleler, hayatımızda tam olarak gerek duyduğumuz şeylerdir. Eğer Allah , hayatımıza hiçbir engelle karsılaşmadan devam etmemize izin verseydi sakat kalırdık.</p>
<p><strong>Simdi ve daha sonra olabileceğimiz kadar güçlü olmazdık. Asla uçamazdık.</strong></p>
</div>]
[<div class="content">
<div class="post-views content-post post-431 entry-meta">
<span class="post-views-icon dashicons dashicons-visibility"></span> <span class="post-views-label">BU YAZIYI OKUYAN KİŞİ SAYISI :</span> <span class="post-views-count">49.875</span>
</div><p><span style="color: #000000;"><strong>Genç bir çiftçi kayığıyla nehirde akıntıya karşı kürek çekerken kan ter içinde kalmıştı. Yetiştirdiği meyveleri köye götürüyordu. Hava çok sıcaktı, bir an evvel teslimatını yapıp karanlık basmadan evine dönmek istiyordu. İleriye baktığında kendi teknesine doğru hızla yaklaşan bir kayık gördü. Yolundan çekilmek için deli gibi kürek çekti ama bir işe yaramadı.</strong></span></p>
<p><span style="color: #000000;">“Yönünü değiştir! Bana çarpacaksın!” diye bağırdı. Ama kayıkta bir değişiklik olmadı ve sonunda ona gelip çarptı. “Gerizekalı!” diye bağırdı çiftçi. “Bu koca nehirde gelip benim kayığıma çarpmayı nasıl başardın?” Kayığa öfkeli bir şekilde bakarken içinde kimsenin olmadığını gördü. Halatından koparak akıntıya kapılan boş bir kayığa bağırıyordu.</span></p>
<p><span style="color: #000000;">Dümeni başka birinin tuttuğunu düşündüğümüz zaman farklı davranırız. Başımıza gelenlerin suçunu o aptal, duyarsız insana atabiliriz. Bu şekilde öfkelenmeye, öfkemizi eyleme vurmaya, suçlu aramaya ve kurban rolünü oynamaya hakkımız olur.</span></p>
<p><span style="color: #000000;">Kayığın boş olduğunu görünce daha sakin davranırız. Suçlayacak bir günah keçisi olmayınca kızamayız. Başımıza gelenlerin kaderin bir oyunu ya da şanssızlık olduğunu kabul ederiz. Hatta halatından kopmuş başıboş gezen bir kayığın koca nehirde gelip bizi bulmasının saçmalığına gülebiliriz.</span></p>
<p><span style="color: #000000;"><strong>Kıssadan hisse; O kayık her zaman boştur. Biz de her zaman boş bir kayığa bağırırız.Boş bir kayık bilerek bize çarpmadığı gibi günümüzü bozuk notalarla dolduran insanların niyeti de bize çarpmak değildir.</strong></span></p>
</div>]
[<div class="content">
<div class="post-views content-post post-850 entry-meta">
<span class="post-views-icon dashicons dashicons-visibility"></span> <span class="post-views-label">BU YAZIYI OKUYAN KİŞİ SAYISI :</span> <span class="post-views-count">9.796</span>
</div><p><b>Çin’in Guangzhou kentinde</b> <i>bir banka soygunu yaşanır. </i>Soygunculardan biri bankadakilere bağırır : “<strong><i>Kımıldamayın ! Para devletindir, ama hayatınız sizindir.</i></strong>” Herkes sessizce yere yatar. Bunun adı “<strong><i>Zihin Değiştirme Kavramı</i></strong>” dır. Alışılmış düşünce tarzını değiştirmek.</p>
<p><b>Bu arada banka çalışanlarından bir kadın</b> masanın üzerine yatmıştır. Ama bacakları da ortadadır. Soyguncu aniden kadına bağırır : “<strong><i>Edebini takın. Bu bir soygun, ırza geçme değil !</i></strong>” Bunun adı “<strong>Profesyonellik</strong>”tir. İşin neyse onun üzerinde yoğunlaş !</p>
<p><b>Soyguncular paraları yüklenip</b> eve kapağı atarlar. Daha genç olanı daha yaşlı olanına “<strong><i>Abi, hadi şu paraları sayalım,</i></strong>” der. Daha yaşlı olanı da : “<i>Çok aptalsın be ! Bu kadar para oturup sayılır mı ? Bu <strong>akşam zaten televizyon haberlerinde kaç para çaldığımızı öğreniriz.</strong></i>” Buna “<strong><i>Deneyim</i></strong>” derler ! Günümüzde <strong>deneyim kâğıt diplomalardan çok daha önemlidir.</strong></p>
<p><b>Soyguncular bankadan kaçtıktan sonra</b> şube müdürü, şube şefine hemen polisi aramasını söylemiş. Ancak şube şefi : “<i>Durun hele müdürüm. Zaten soyguncular alacaklarını aldılar.<strong> Biz de bir 10 milyon daha alıp daha önce iç ettiğimiz 70 milyon dolara ekleyelim, ne dersiniz ?</strong></i>” Buna “<strong><i>Dalgayı Yakalamak</i></strong>” derler. Berbat bir durumu kendi lehine çevirmektir bu !</p>
<p><b>Banka müdürü :</b> “<i>Yahu, <strong>her ay bir soygun olsa harika olurdu</strong>. Ne eğlenirdik !</i>”der. Buna “<strong><i>Sıkıntılardan Kurtulmak</i></strong>” denir. Kişisel mutluluk işinden çok daha önemlidir.</p>
<p><b>Akşam televizyon haberleri</b> <i>bankadan</i><strong> 100 milyon dolar</strong> <i>çalındığını</i> açıklamış ! Çaldıkları paranın çok daha az olduğu bilen soyguncular oturup saymışlar parayı. Tekrar tekrar saymışlar. <strong><em>Bakmışlar ki çaldıkları para hepi topu 20 milyon !</em></strong></p>
<p><b>Bu işe çok sinirlenen soyguncular :</b> “<i>Biz hayatımızı tehlikeye atıp <strong>20 milyon çalabildik. Banka müdürü bir el hareketiyle 80 milyon götürdü.</strong> Galiba soyguncu olmak yerine doğru dürüst eğitim görmek daha iyiymiş !</i>” Bu “<strong><i>Bilgi Altından Daha Değerlidir</i></strong>” demektir.</p>
<p><b>Banka müdürü çok mutludur.</b> Özellikle bir süre önce borsada kaybettiklerini geri alabildiği için. Buna “<strong><i>Fırsatları Kullanmak</i></strong>” derler. Kazanmak için risk almak gerekir.</p>
<p><em><strong>Sizce, gerçek soyguncular kimler ?</strong></em></p>
</div>]
          '''
sentences = sent_tokenize(text, language='turkish')

print(20 * "-")
print(sentences)
print(20 * "-")
print("Toplam cümle: ", len(sentences))
stop_words = set(stopwords.words('turkish'))

print(10 * "-", " etkisiz kelimeler ", 10 * "-")
print(stop_words)
print(20 * "-")
words = word_tokenize(text)

print( 20 * "-")
print(words)
print(20 * "-")
print("Metninizdeki toplam kelime sayısı: ", len(words))
print(20 * "-")


words = [word.lower() for word in words if word.isalpha()]
words = [word for word in words if word not in stop_words]

print(10 * "-", " Etkisiz kelimeler hariç küçük harfli kelimeler ", 10 * "-")
print(words)
print(20 * "-")
print("Metninizdeki toplam kelime sayısı:", len(words))
print(20 * "-")


lemmatizer = WordNetLemmatizer()

words = [lemmatizer.lemmatize(word) for word in words]

print(10 * "-", " Kelimelerin Başlangıç Hali ", 10 * "-")
print(words)
print(20 * "-")
print("Metninizdeki toplam kelime sayısı: ", len(words))
print(20 * "-")


freq_dist = FreqDist(words)
sentence_scores = {}

for i, sentence in enumerate(sentences):
    sentence_words = word_tokenize(sentence.lower())
    sentence_score = sum([freq_dist[word] for word in sentence_words if word in freq_dist])

    sentence_scores[i] = sentence_score

sentence_scores
sorted_scores = sorted(sentence_scores.items(), key=lambda x: x[1], reverse=True)

sorted_scores
selected_sentences = sorted_scores[:1]
selected_sentences = sorted(selected_sentences)

# Özet oluşturma
summary = ' '.join([sentences[i] for i, _ in selected_sentences])
print(summary)