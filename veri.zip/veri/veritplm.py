import requests
from bs4 import BeautifulSoup
import requests
import pandas as pd
import numpy as np
from html.parser import HTMLParser


url = 'http://www.tufangul.com/'
pages = ["kral-ve-yasli-adam-acele-karar-vermeyin", "bir-sey-ancak-degerini-bilenin-yaninda-kiymetlidir", "koza-ve-kelebek", "o-kayik-her-zaman-bostur", "bakis-acisini-degistirmek-zihin-degistirme-kavrami"]

for i in pages:
    response = requests.get(url + i + "/")
    bs = BeautifulSoup(response.text)

    temp = bs.find_all("div","content")
    print(temp)
   
        


df = pd.DataFrame(temp)

# Veriyi bir metin dosyasına kaydetmek için to_csv işlemini kullanın
df.to_csv('./veri.txt', sep='\t', index=False)  # sep='\t', sekme karakteriyle sütunları ayırır

