import pytube
from pytube import YouTube

link = input("URL:")
link = str(link)
youtube = pytube.YouTube(link)
youtube.streams.first().download()

print("İndirildi", link)